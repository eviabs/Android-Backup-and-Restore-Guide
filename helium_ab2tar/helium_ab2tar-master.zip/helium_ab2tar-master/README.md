# Utility for converting Helium Backup file into regular TAR file

This tool was originally available as Helium_ab2tar.zip, original copy seems to have vanished.

Archived for convenience here, all copyright (c) original authors.

## License

Originally written by xaos.cz @ XDA-Devs

Makefile by seXneo @ XDA-Devs

http://forum.xda-developers.com/showthread.php?t=2616961

## Usage:

    ab2tar_cut [.ab file] [temporary file]
    ab2tar_corr [temporary file] [.tar file]

