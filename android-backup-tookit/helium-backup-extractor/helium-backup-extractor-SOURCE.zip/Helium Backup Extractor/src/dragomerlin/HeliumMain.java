/** 
	Copyright 2013 dragomerlin
	
 	This file is part of Helium Backup Extractor.
  
    Helium Backup Extractor is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Helium Backup Extractor is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Helium Backup Extractor. If not, see <http://www.gnu.org/licenses/>.
 */

/* POSIX header from src/tar.h*/

//struct posix_header
//{				/* byte offset */
//  char name[100];		/*   0 */
//  char mode[8];			/* 100 */
//  char uid[8];			/* 108 */
//  char gid[8];			/* 116 */
//  char size[12];		/* 124 */
//  char mtime[12];		/* 136 */
//  char chksum[8];		/* 148 */
//  char typeflag;		/* 156 */
//  char linkname[100];		/* 157 */
//  char magic[6];		/* 257 */
//  char version[2];		/* 263 */
//  char uname[32];		/* 265 */
//  char gname[32];		/* 297 */
//  char devmajor[8];		/* 329 */
//  char devminor[8];		/* 337 */
//  char prefix[155];		/* 345 */
//				/* 500 */
//};

package dragomerlin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class HeliumMain {
	
	public static final int HELIUM_CARBON_HEADER = 31;
	public static final int TAR_HEADER_SIZE = 512;
	public static final int TAR_NAME_SIZE = 100;
	public static final int TAR_SIZE_START = 124;
	public static final int TAR_SIZE_SIZE = 12;
	public static final int TAR_CHKSUM_START = 148;
	public static final int TAR_CHKSUM_SIZE = 8;
	public static final int TAR_TYPEFLAG_START = 156;
	
	
	public static void main(String args[]) throws IOException {
		
		if (args.length < 2) {
			System.out.println("Helium Backup Extractor");
			System.out.println("Extract using tar specifications:");
			System.out.println("\tjava -jar hbe.jar -tar backup.ab");
			System.out.println("Brute force method (when the other doesn't work):");
			System.out.println("\tjava -jar hbe.jar -force backup.ab");
        	System.exit(1);
        }
		
		File testfile = new File(args[1]);
		if (!testfile.isFile() || !testfile.exists()){
			System.out.println("File " + args[1] + " doesn't exist.");
			System.exit(1);
		}
		
		if (args[0].equals("-tar")){
			tar_noenc(args[1]);
			System.exit(0);
		} else if (args[0].equals("-force")){
			System.out.println(args[1]);
			force_noenc(args[1]);
			System.exit(0);
		} else {
			System.out.println("Invalid option " + args[0]);
			System.exit(1);
		}
	}
	
	public static void tar_noenc(String args) throws IOException{
		// This method relies on size for each file specified
		// in posix header.
		String workingdir = new File(System.getProperty("user.dir")).toString();
		// Open file
		File file = new File(args);
		FileInputStream fin = new FileInputStream(file);
		byte fileContent[] = new byte[(int)file.length()];
		fin.read(fileContent);
		String strFileContent = new String(fileContent);
		
		// Discard the ab header (first 31 characters)
		int counter = HELIUM_CARBON_HEADER;
//		int counterend = counter;
		String name = null;
		String fullname = null;
		String sizeoct = null;
		int sizedec = 0;
		String checksum = null;
		char filetype = '0';
//		String itemdata = null;
		
		// The last four chars correspond to file ending, not data.
		//*//int backupsize = strFileContent.length();
		int backupsize = (int)file.length();
		
		// Read files one by one
		while(counter < backupsize -4){
			
			// Skip null data (if exists)
			while (fileContent[counter] == 0x0){
				counter++;
			}
			
			// Check that we are not at the end of the backup. If so, exit
			// Also give 5 chars margin for next 'apps/'
			if  (counter > backupsize -5){
				fin.close();
				System.exit(0);
			}
			
			// There should go the string 'apps/', exit if not
			if (fileContent[counter] != 'a' ||
				fileContent[counter+1] != 'p' ||
				fileContent[counter+2] != 'p' ||
				fileContent[counter+3] != 's' ||
				fileContent[counter+4] != '/'){
				System.out.println("counter es "+counter);
				System.out.println("Error. apps/ should be here");
				System.exit(1);
			}
			
			// Read name (relative path)
			name = strFileContent.substring(counter, counter + TAR_NAME_SIZE);
			
			// Read size (in octal)
			sizeoct = strFileContent.substring(counter + TAR_SIZE_START, counter + TAR_SIZE_START + TAR_SIZE_SIZE);
			sizedec = Integer.parseInt(sizeoct,8);
			
			// Read checksum
			checksum = strFileContent.substring(counter + TAR_CHKSUM_START, counter + TAR_CHKSUM_START + TAR_CHKSUM_SIZE);
			
			// Read filetype (to know if is a file or directory mainly)
			// 0 is a file and 5 a dir. Dirs have size 0.
			filetype = strFileContent.charAt(counter + TAR_TYPEFLAG_START);
			
			// Move to where data should start (may be nulls prior)
			counter = counter + TAR_HEADER_SIZE;
			
			// Update
			fullname = workingdir + File.separator + name;
			String dironly = fullname.substring(0, fullname.lastIndexOf("/"));
			File newdir = new File(dironly);
			File fileout = new File(fullname);
			
			if (filetype == '5'){
				if (sizedec == 0){
					// Is directory. Create it if doesn't exist.
					if (newdir.exists() && newdir.isFile()){
						newdir.delete(); // It's not really a dir
					}
					if (!newdir.exists())
						newdir.mkdirs();
				}
				else {
					System.out.println("Error. Directories should have size 0");
					System.exit(1);
				}
			}
			else if (filetype == '0' || filetype == '\0'){
				if (sizedec == 0){
					// Create an empty file
					fileout.createNewFile();
				}
				else {
					// File is bigger than 0.
					if (!newdir.exists()){
						newdir.mkdirs();
					}
					FileOutputStream fos = new FileOutputStream(fileout);
					fos.write(fileContent, counter, sizedec);
					fos.close();
					
					//*//itemdata = strFileContent.substring(counter, counter+sizedec);
					
					counter = counter + sizedec;
					
					// Buggy adb decompressed backups: sometimes data still continues to show 
					// (mixed with null characters or not) even after sizedec, so it's
					// better to ignore it until next 'apps/' because if not file
					// won't match same size.
					// This happens sometimes on cache files, for example:
					// com.topfreegames.bikeracefreeworld/r/app_webview/Cache/ce0fcd9e7ac216a3_1
					
					// Lookup for next 'apps/', but don't exit if we are at end of file, since
					// there's data yet to be written.
					int endcount = counter;
					boolean isdata = false;
					while (endcount < backupsize -4 &&
							(fileContent[endcount] != 'a' 
							|| fileContent[endcount+1] != 'p'
							|| fileContent[endcount+2] != 'p'
							|| fileContent[endcount+3] != 's'
							|| fileContent[endcount+4] != '/')){
						if (fileContent[endcount] != 0x0)
							isdata = true;
						endcount++;
					}
					counter = endcount;
					
//					while (fileContent[counter] != 0x0 
//							&& sizedec != 0
//							&& (fileContent[counter] != 'a' 
//							|| fileContent[counter+1] != 'p'
//							|| fileContent[counter+2] != 'p'
//							|| fileContent[counter+3] != 's'
//							|| fileContent[counter+4] != '/')) {
//						itemdata += strFileContent.substring(counter, counter+1);
//						counter++;
//					}
					
//					if (itemdata != null){
//						if (!newdir.exists())
//							newdir.mkdirs();
//						FileOutputStream fos = new FileOutputStream(fileout);
//						fos.write(itemdata.getBytes());
//						fos.close();
//					}
//					else {
//						System.out.println("Error. itemdata shouldn't be null");
//						System.exit(1);
//					}
				}
			}
			else {
				System.out.println("Error. Filetype " + filetype + " does not match file or directory");
				System.exit(1);
			}
		}
		System.out.println("End reached.");
	}
	
	
	public static void tar_method_not_working(String args) throws IOException{
		// This method relies on size for each file specified
		// in posix header.
		
		String workingdir = new File(System.getProperty("user.dir")).toString();
		
		// Open file
		File file = new File(args);
		FileInputStream fin = new FileInputStream(file);
		byte fileContent[] = new byte[(int)file.length()];
		fin.read(fileContent);
		String strFileContent = new String(fileContent);
		
		// Discard the ab header (first 31 characters)
		int counter = 31;
		int counterend = counter;
		String name = null;
		String fullname = null;
		String sizeoct = null;
		int sizedec = 0;
		
		// The last four chars correspond to file ending, not data.
		int backupsize = strFileContent.length();
		
		// Read files one by one
		while(counter < backupsize -4){

			// Skip null data (if exists)
			while (fileContent[counter] == 0x0){
				counter++;
			}

			// Check that we are not at the end of the backup. If so, exit
			if  (counter >= backupsize -4){
				fin.close();
				System.exit(0);
			}
			counterend = counter;

			// Read name (path)
			while (fileContent[counterend] != 0x0){
				counterend++;
			}
			name = strFileContent.substring(counter, counterend);
			counter = counterend;

			// Skip null characters
			while (fileContent[counter] == 0x0){
				counter++;
			}

			// Skip first 3 tar blocks of data
			counter = counter + 24;

			// Next 12 correspond to size in octal.
			sizeoct = strFileContent.substring(counter, counter+12);
			sizedec = Integer.parseInt(sizeoct,8);

			// Read until r from ustar
			while (fileContent[counter] != 'r'){
				counter++;
			}
			counter++;

			// Skip zeroes (if exist)
			while (fileContent[counter] == 0x0){
				counter++;
			}

			// Skip 15 positions (two blocks of tar data with its separator)
			counter = counter + 15;

			// Skip zeroes
			while (fileContent[counter] == 0x0){
				counter++;
			}

			// Now data starts for the file, with size sizedec,
			// unless size if zero.
			String itemdata = null;
			if (sizedec > 0) {
				itemdata = strFileContent.substring(counter, counter+sizedec);
				counter = counter+sizedec;
			}

			 //  if next character is not null keep adding
			 // unless it's the start of the next item.
//						while (fileContent[counter] != 0x0 
//								&& sizedec != 0
//								&& (fileContent[counter] != 'a' 
//									|| fileContent[counter+1] != 'p'
//									|| fileContent[counter+2] != 'p'
//									|| fileContent[counter+3] != 's'
//									|| fileContent[counter+4] != '/')) {
//							itemdata += strFileContent.substring(counter, counter+1);
//							counter++;
//						}

			fullname = workingdir + File.separator + name;
			String dironly = fullname.substring(0, fullname.lastIndexOf("/"));
			File newdir = new File(dironly);
			// Warning: sometimes 0 size files are directories in the end. Fix it here.
			if (newdir.exists() && newdir.isFile()){
				newdir.delete(); // It's not really a dir
			}
			if (!newdir.exists())
				newdir.mkdirs();
			File fileout = new File(fullname);
//			if (fileout.exists()) {
//				fileout.delete();
//			}
			//fileout.createNewFile();
			
			// don't write to a directory
			if (itemdata != null) {
				FileOutputStream fos = new FileOutputStream(fileout);
				fos.write(itemdata.getBytes());
				fos.close();
			} else {
				// Create empty file
				fileout.createNewFile();
			}
		}
	}
	
	public static void force_noenc(String args) throws IOException{
		// This method gets the data between a file name and the next and trims null chars at the end.
		// That data will be considered the file (ignores size specified in posix header)
		
		String workingdir = new File(System.getProperty("user.dir")).toString();
		boolean endreached = false;
		// Open file
		File file = new File(args);
		FileInputStream fin = new FileInputStream(file);
		byte fileContent[] = new byte[(int)file.length()];
		fin.read(fileContent);
		String strFileContent = new String(fileContent);
		
		// Discard the ab header (first 31 characters)
		int counter = 31;
		int counterend = counter;
		String name = null;
		String fullname = null;
		
		// The last four chars correspond to file ending, not data.
		int backupsize = strFileContent.length();
		
		// Read files one by one
		while(counter < backupsize -4){

			// Skip null data (if exists)
			while (fileContent[counter] == 0x0){
				counter++;
			}


			// Check that we are not at the end of the backup. If so, exit
			if  (counter >= backupsize -4){
				fin.close();
				System.exit(0);
			}
			counterend = counter;

			// Read name (path)
			while (fileContent[counterend] != 0x0){
				counterend++;
			}
			name = strFileContent.substring(counter, counterend);
			counter = counterend;

			// Skip null characters
			while (fileContent[counter] == 0x0){
				counter++;
			}

			// Skip first 3 tar blocks of data
//			counter = counter + 24;

			// Next 12 correspond to size in octal.
//			sizeoct = strFileContent.substring(counter, counter+12);
//			sizedec = Integer.parseInt(sizeoct,8);

			// Read until r from ustar
			while (fileContent[counter] != 'r'){
				counter++;
			}
			counter++; 

			// Skip zeroes (if exist)
			while (fileContent[counter] == 0x0){
				counter++;
			}

			// Skip 15 positions (two blocks of tar data with its separator)
			counter = counter + 15;
			
			// Warning with empty files
			// Skip zeroes (if exist)
			boolean dataexists = false;
			while (fileContent[counter] == 0x0){
				counter++;
			}
	
			// Now data starts for the file, with size yet to determine.
			// Read until next "apps/" is found. Hope that string is not inside any file itself
			// or will mistake it for the name of the next file.
			counterend = counter;
			
			if (counterend >= backupsize -4)
				endreached = true;
			while (!endreached &&
					(fileContent[counterend] != 'a'
					|| fileContent[counterend+1] != 'p'
					|| fileContent[counterend+2] != 'p'
					|| fileContent[counterend+3] != 's'
					|| fileContent[counterend+4] != '/')){
				if (counterend >= backupsize -4){
					endreached = true;
				}
				// If there are only zeroes when reaching next "apps/"
				// the file is zero size.
				if (fileContent[counterend] != 0x0 && !endreached){
					dataexists = true;
				}
				if (!endreached)
					counterend++;
			}
			
//			while (	!endreached &&
//					(fileContent[counterend] != 'a'
//					|| fileContent[counterend+1] != 'p'
//					|| fileContent[counterend+2] != 'p'
//					|| fileContent[counterend+3] != 's'
//					|| fileContent[counterend+4] != '/')){
//				if  (fileContent[counterend] == -69
//						&& fileContent[counterend+1] == -74
//						&& fileContent[counterend+2] == 59
//						&& fileContent[counterend+3] == -103) {
//							endreached = true;
//							System.out.println("End reached!"); 
//						}
//				// If there are only zeroes when reaching next "apps/"
//				// the file is zero size.
//				if (fileContent[counterend] != 0x0 && !endreached){
//					dataexists = true;
//				}
//				if (!endreached)
//					counterend++;
//			}
			
			// Now we have found the name of the next file that starts at counterend.
			// Go backwards skipping zeroes unless the file is zero size.
			String itemdata = null;
			if (dataexists){
				counterend--;
				while (fileContent[counterend] == 0x0){
					counterend--;
				}
				counterend++;
				itemdata = strFileContent.substring(counter, counterend);
				counter = counterend;
			} else {
				itemdata = null;
				counter = counterend;
			}
						
			fullname = workingdir + File.separator + name;
			String dironly = fullname.substring(0, fullname.lastIndexOf("/"));
			File newdir = new File(dironly);
			// Warning: sometimes 0 size files are directories in the end. Fix it here.
			if (newdir.exists() && newdir.isFile()){
				newdir.delete(); // It's not really a dir
			}
			if (!newdir.exists())
				newdir.mkdirs();
			File fileout = new File(fullname);
//			if (fileout.exists()) {
//				fileout.delete();
//			}
			//fileout.createNewFile();
			
			// don't write to a directory
			if (itemdata != null) {
				FileOutputStream fos = new FileOutputStream(fileout);
				fos.write(itemdata.getBytes());
				fos.close();
			} else {
				// Create empty file
				fileout.createNewFile();
			}
		}
	}
}
